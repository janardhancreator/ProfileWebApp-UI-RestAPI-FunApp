import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutmeComponent } from './components/aboutme/aboutme.component';
import { AreaOfExpertiseComponent } from './components/area-of-expertise/area-of-expertise.component';
import { WorkexperienceComponent } from './components/workexperience/workexperience.component';
import { AchievementsGoalsComponent } from './components/achievements-goals/achievements-goals.component';
import { TrainingsAttendedComponent } from './components/trainings-attended/trainings-attended.component';
import { ContactmeComponent } from './components/contactme/contactme.component';

export const routes: Routes = [
    {path:'',redirectTo:'/home',pathMatch:'full'},
    {path:"home",component:HomeComponent},
    {path:'aboutme',component:AboutmeComponent},
    {path:'expertise',component:AreaOfExpertiseComponent},
    {path:'experience',component:WorkexperienceComponent},
    {path:'hobbies',component:AchievementsGoalsComponent},
    {path:'trainings',component:TrainingsAttendedComponent},
    {path:'contactme',component:ContactmeComponent}
];
