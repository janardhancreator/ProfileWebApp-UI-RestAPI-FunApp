import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AreaOfExpertiseComponent } from './components/area-of-expertise/area-of-expertise.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,RouterLink,AreaOfExpertiseComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'profilewebapp';
}
