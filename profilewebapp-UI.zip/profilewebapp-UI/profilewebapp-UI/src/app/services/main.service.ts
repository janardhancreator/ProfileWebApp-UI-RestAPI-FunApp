import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MainService {

  expertiseList:any
  contactDetails:any
  profilehomepage:any;
  private expertiseAPIUrl ='https://janardhanwebapp-cge4eshjegajgrb0.southindia-01.azurewebsites.net/api/expertise';
  private saveContactDetailsAPIUrl="https://janardhanwebapp-cge4eshjegajgrb0.southindia-01.azurewebsites.net/api/savecontactdetails";
  private homeAPIUrl="https://janardhanwebapp-cge4eshjegajgrb0.southindia-01.azurewebsites.net/api/home";
  private expertiseSaveAPIUrl="https://janardhanwebapp-cge4eshjegajgrb0.southindia-01.azurewebsites.net/api/saveexpertise";
  private getContactDetailsAPIURL="https://janardhanwebapp-cge4eshjegajgrb0.southindia-01.azurewebsites.net/api/contactdetails"
  private apiurl="https://emailsendfuncapp.azurewebsites.net/api/SendContactEmail?code=nyHRX-SINItbpnmoXPORj1rsbVynj6mnnm8-f9d8NvlOAzFuXO9diA%3D%3D";
   constructor(private http:HttpClient)
  {}

  getExpertiseDetails(){
    this.http.get(this.expertiseAPIUrl).subscribe(result=>
    {
      this.expertiseList=result;
      // console.log(this.expertiseList);
    })
  }

  
 
  submitContactData(contactData:any):Observable<any>
    //  {name:string, email:string, phoneNo:string,description:string}
   {
     const data={      
        name:contactData.value.name,
        email:contactData.value.email,
        phoneNo: contactData.value.phoneNo,
        description:contactData.value.description    
    
     }
     return this.http.post<any>(this.saveContactDetailsAPIUrl,data)
    
  }
  saveExpertiseFormData(expertiseFormData:any):Observable<any>
  {
    const expertiseData={
      name: expertiseFormData.value.name,
      description: expertiseFormData.value.description,
      details: expertiseFormData.value.details
    }  
    return this.http.post<any>(this.expertiseSaveAPIUrl,expertiseData);
  }

  getContactDetails()
  {
    this.http.get(this.getContactDetailsAPIURL).subscribe(result=>
      {
        this.contactDetails=result;
      })
  }
  
  sendContact(contactData: { name: string; email: string }) {
    this.http.post(this.apiurl, contactData).subscribe({
      next: (response) => {
        alert('Contact created and email sent successfully!');
      },
      error: (error) => {
        alert('Failed to send email. Please try again later.');
        console.error('Error details:', error);
      }
    });
  }
    
}
