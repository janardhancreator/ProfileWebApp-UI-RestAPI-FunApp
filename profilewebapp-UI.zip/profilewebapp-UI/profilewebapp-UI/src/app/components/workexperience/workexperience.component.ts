import { Component } from '@angular/core';

@Component({
  selector: 'app-workexperience',
  imports: [],
  templateUrl: './workexperience.component.html',
  styleUrl: './workexperience.component.css'
})
export class WorkexperienceComponent {

}
