import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingsAttendedComponent } from './trainings-attended.component';

describe('TrainingsAttendedComponent', () => {
  let component: TrainingsAttendedComponent;
  let fixture: ComponentFixture<TrainingsAttendedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrainingsAttendedComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainingsAttendedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
