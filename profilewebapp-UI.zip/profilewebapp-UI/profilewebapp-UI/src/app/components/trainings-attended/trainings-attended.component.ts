import { Component } from '@angular/core';

@Component({
  selector: 'app-trainings-attended',
  imports: [],
  templateUrl: './trainings-attended.component.html',
  styleUrl: './trainings-attended.component.css'
})
export class TrainingsAttendedComponent {

}
