import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MainService } from '../../services/main.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contactme',
  imports: [FormsModule,NgIf,NgFor],
  templateUrl: './contactme.component.html',
  styleUrl: './contactme.component.css'
})
export class ContactmeComponent {
  showContactRegisterForm=false;
  showTableHead=false;
  mainService:MainService;
  
  constructor(mainServiceRef:MainService)
  {
this.mainService=mainServiceRef;

  }
 
    onSubmit(formData:any) {
    
     
        this.mainService.submitContactData(formData).subscribe(result=>{
          console.log('Contact data submitted successfully', result);
          alert("Contact data submitted successfully");
        }, error => {
          console.error('Error submitting contact data', error);
        });

   

this.mainService.sendContact({name:formData.value.name,email:formData.value.email});




      }



      
      toggleTableHeader() {
        this.showTableHead = !this.showTableHead;
        this.mainService.getContactDetails();  
      }


      
 

}
