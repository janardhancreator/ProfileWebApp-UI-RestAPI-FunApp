import { Component } from '@angular/core';

@Component({
  selector: 'app-achievements-goals',
  imports: [],
  templateUrl: './achievements-goals.component.html',
  styleUrl: './achievements-goals.component.css'
})
export class AchievementsGoalsComponent {

}
