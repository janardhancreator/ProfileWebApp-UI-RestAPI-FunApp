import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementsGoalsComponent } from './achievements-goals.component';

describe('AchievementsGoalsComponent', () => {
  let component: AchievementsGoalsComponent;
  let fixture: ComponentFixture<AchievementsGoalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AchievementsGoalsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AchievementsGoalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
