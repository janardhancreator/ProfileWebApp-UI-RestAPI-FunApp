import { Component } from '@angular/core';
import { MainService } from '../../services/main.service';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-area-of-expertise',
  imports: [NgFor,FormsModule,NgIf],
  templateUrl: './area-of-expertise.component.html',
  styleUrl: './area-of-expertise.component.css'
})
export class AreaOfExpertiseComponent {
  showExpertiseForm =false;
  mainService:MainService
  constructor(mainServiceRef:MainService)
  {
    this.mainService=mainServiceRef;
  }
  ngOnInit(): void {}
  
  expertiseFormDetailsSubmit(expertiseFormData2:any)
  {
    this.mainService.saveExpertiseFormData(expertiseFormData2).subscribe(result=>
      {
        alert("Expertise data submitted successfully:");
        console.log("expertise form data successfully" , result);
      },error=>
      {
      console.error("Error occured while submitting the expertise Data",error);
      }
      )
  }
}
