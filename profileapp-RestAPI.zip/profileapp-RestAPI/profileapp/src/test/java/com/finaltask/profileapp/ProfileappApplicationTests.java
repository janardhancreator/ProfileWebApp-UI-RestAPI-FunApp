package com.finaltask.profileapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileappApplicationTests {

	@Test
	void contextLoads() {
	}

}
