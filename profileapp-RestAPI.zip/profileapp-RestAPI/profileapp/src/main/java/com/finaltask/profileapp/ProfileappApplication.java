package com.finaltask.profileapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfileappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfileappApplication.class, args);
	}

}
